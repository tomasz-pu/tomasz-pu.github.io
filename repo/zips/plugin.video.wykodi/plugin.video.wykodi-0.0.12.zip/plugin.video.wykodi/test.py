'''
from modules.processor import get_video_url

print(get_video_url('ST', 'https://streamable.com/5jo983'))
'''

'''
from modules.handler import get_videos

secret = "16deaa723d3fb42731f89a947ffd3608"
key = 'w5399382426'

sel_cat = {'params': {'endpoint': 'links', 'type': 'homepage', 'sort': 'active', 'page': 1}, 'category': {'name': 'Aktywne', 'descr': 'Wykop - Aktywne wykopy', 'params': {'sort': 'active'}}, 'mode': 'wykop01'}

#sel_cat = {'params': {'endpoint': 'entries','sort': 'active'}, 'category': {'name': 'Aktywne', 'descr': 'Wykop - Aktywne wykopy', 'params': {'sort': 'active'}}, 'mode': 'wykop02'}

#sel_cat = {'params': {'endpoint': 'entries','sort': 'newest'}, 'category': {'name': 'Aktywne', 'descr': 'Wykop - Aktywne wykopy', 'params': {'sort': 'newest'}}, 'mode': 'wykop02'}

_videos = get_videos(sel_cat['mode'], sel_cat['params'], key, secret)
print(_videos)



aa = {
    'id': 7020901, 
    'created_at': '2023-02-18 18:38:35', 
    'title': 'Skończyło się zapieprzanie dla tego pana...', 
    'slug': 'skonczylo-sie-zapieprzanie-dla-tego-pana', 
    'description': '42-letni kierowca Forda zginął na miejscu. 28-letniemu kierowcy ciężarówki nie stało się nic poważnego. Czy inni wyciągną wnioski?', 
    'source': {'label': 'www.youtube.com', 'url': 'https://www.youtube.com/watch?v=tnLoSE9w9Zk', 'type': 'anchor', 'type_id': 7020901}, 
    'author': {'username': 'LudzieToDebile', 'gender': 'm', 'company': False, 'avatar': '', 'status': 'active', 'color': 'burgundy', 'verified': False, 'rank': {'position': 223, 'trend': 1}, 'blacklist': False, 'follow': False, 'note': False, 'online': False},
    'published_at': '2023-02-18 21:37:19', 
    'votes': {'up': 197, 'down': 15, 'count': 182}, 'voted': 0, 
    'comments': {'hot': False, 'count': 141}, 
    'tags': ['samochodoza', 'samochody', 'wypadek'], 
    'hot': False, 
    'adult': False, 
    'media': {
        'photo': {
            'key': 'MrD1EOPxY60Q8N54wAbLyK4e91JPjZJR2p9Xndvk3Veg7lWBqa', 
            'label': 'hqdefault', 
            'mime_type': 'image/jpeg', 
            'url': 'https://wykop.pl/cdn/c3397993/106b24c7115ba9cb028f53b90b1268756c99ebf30ecc6bb7bede26f2c0fccf23.jpg', 
            'size': 40585, 
            'width': 480, 
            'height': 360}, 
            'embed': {
                'key': '5YzP39N7AvkODJWMEpRZ8Kvgr735jw2XBlbyrVL6dmgeQa1x4q', 
                'type': 'youtube', 
                'thumbnail': 'https://wykop.pl/cdn/c3397993/7e6742cca9a23ffafb80f389e3a6025e56ea7f93ebceee97e5c7923e14d0c1ef.jpg', 'url': 'https://www.youtube.com/watch?v=tnLoSE9w9Zk'}
            }, 'editable': False, 'deletable': False, 'resource': 'link', 'actions': {'create': False, 'update': False, 'delete': False, 'vote_up': False, 'vote_down': False, 'undo_vote': False, 'start_ama': False, 'finish_ama': False, 'create_favourite': False, 'delete_favourite': False, 'report': False}, 'archive': False, 'parent': None}

entry = {
    "id": 70468687,
    "slug": "koreanka-kazuha-lesserafim-japonka",
    "author": {
        "username": "XKHYCCB2dX",
        "gender": "f",
        "company": False,
        "avatar": "https://wykop.pl/cdn/c3397992/XKHYCCB2dX_dXs6quroLi.jpg",
        "status": "active",
        "color": "orange",
        "verified": False,
        "rank": {"position": 1558, "trend": -1},
        "blacklist": False,
        "follow": False,
        "note": False,
        "online": False,
    },
    "device": "",
    "created_at": "2023-02-19 13:39:37",
    "voted": 0,
    "content": "#koreanka #kazuha #lesserafim #japonka",
    "media": {
        "photo": None,
        "embed": {
            "key": "pml3PzYD60n5L9gJ7yekVoEvYEM0K8MZrd2XQvE1BARqwOxbW4",
            "type": "youtube",
            "thumbnail": "https://wykop.pl/cdn/c3201142/2596c67a72ef74062ddcaa28e3ee3e3301e60aed4534a814166fdd78cc782f3c.jpg",
            "url": "https://www.youtube.com/watch?v=6KxnVpttbJE",
        },
        "survey": None,
    },
    "adult": False,
    "tags": ["koreanka", "kazuha", "lesserafim", "japonka"],
    "favourite": False,
    "parent": None,
    "votes": {"up": 0, "down": 0, "users": []},
    "editable": False,
    "deletable": False,
    "comments": {"items": [], "count": 0},
    "resource": "entry",
    "actions": {
        "create": False,
        "update": False,
        "delete": False,
        "vote_up": False,
        "create_favourite": False,
        "delete_favourite": False,
        "report": False,
    },
    "archive": False,
    "status": "visible",
}
'''


'''
_MENU = {
    10: {
        'name': 'Main Menu',
        'descr': '',
        'subcategories': {
            10: {
                'name': 'Wykop',
                'descr': 'Displays videos from the [B][COLOR blue]Wykop[/COLOR][/B]',
                'params': {
                    'endpoint': 'links',
                    'type': 'homepage'
                },
                'call_m': 'wykop01',
                'subcategories': {
                    10: {
                        'name': 'Najnowsze',
                        'descr': 'Wykop - Najnowsze wykopy',
                        'params': {'sort': 'newest'}
                    },
                    11: {
                        'name': 'Aktywne',
                        'descr': 'Wykop - Aktywne wykopy',
                        'params': {'sort': 'active'}
                    },
                    12: {
                        'name': 'Komentowane',
                        'descr': 'Wykop - Komentowane wykopy',
                        'params': {'sort': 'commented'}
                    },
                    13: {
                        'name': 'Wykopane',
                        'descr': 'Wykop - Wykopane wykopy',
                        'params': {'sort': 'digged'}
                    }
                }
            },
            11: {
                'name': 'Wykopalisko',
                'descr': 'Displays videos from the [B][COLOR blue]Wykopalisko[/COLOR][/B]',
                'params': {
                    'endpoint': 'links',
                    'type': 'upcoming'
                },
                'call_m': 'wykop01',
                'subcategories': {
                    10: {
                        'name': 'Najnowsze',
                        'descr': 'Wykopalisko - Najnowsze wykopy',
                        'params': {'sort': 'newest'}
                    },
                    11: {
                        'name': 'Aktywne',
                        'descr': 'Wykopalisko - Aktywne wykopy',
                        'params': {'sort': 'active'}
                    },
                    12: {
                        'name': 'Komentowane',
                        'descr': 'Wykopalisko - Komentowane wykopy',
                        'params': {'sort': 'commented'}
                    },
                    13: {
                        'name': 'Wykopane',
                        'descr': 'Wykopalisko - Wykopane wykopy',
                        'params': {'sort': 'digged'}
                    }
                }
            }
        }
    }
}

def get_cat_details(cat_id: str) -> dict:
    _details = {}
    _details['params'] = {}
    for inx, level in enumerate([int(x) for x in cat_id.split('-')]):
        _details['category'] = _details['category']['subcategories'][level] if inx > 0 else _MENU[level]
        if 'params' in _details['category'].keys():
            for par_name, par_val in _details['category']['params'].items():
                _details['params'][par_name] = par_val
    return _details

print(get_cat_details("10-10-11"))
'''
'''
number = int(input('Please give me a number for my times table\n'))
for x in range(101):
    print(f'{number} x {x} = {x*number}')
'''

'''
numbers = input('Please give me 2 numbers separated by x\n')
numbers_list = [int(x) for x in numbers.split('x')]
print(f'{numbers_list[0]} x {numbers_list[1]} = {numbers_list[0]*numbers_list[1]}')
'''

'''1
from modules.config import _MENU

def select_cat(cat_id: str):
    _sel_cat = _MENU
    for inx, level in enumerate([int(x) for x in cat_id.split('-')]):
        _sel_cat = _sel_cat['subcategories'][level] if inx > 0 else _MENU[level]
    return _sel_cat

def get_content(cat_id = 10) -> None:
    # get the exact tree
    sel_cat = select_cat(str(cat_id))
    print(sel_cat)

get_content("10-10-11")
'''

''''''
from modules.api_wrapper import call_wykop, get_JWT_token

secret = "16deaa723d3fb42731f89a947ffd3608"
key = 'w5399382426'

token = get_JWT_token(key, secret)
#print(token)
test2 = call_wykop(token, 1, 'Wykop', '')
print(test2)
''''''

