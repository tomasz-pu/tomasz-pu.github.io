import xbmcaddon

_PLUGIN_NAME = 'plugin.video.wykodi'

_VIDEO_PROVIDERS = {
    "youtube": "YT",
    "youtu.be": "YT",
    "streamable.com": "ST",
    "gfycat.com": "GFY"
}

_TRACK_PLAYS = eval(
        xbmcaddon.Addon(id=_PLUGIN_NAME).getSetting('track.play').capitalize()
    )

# wykop credentials
API_KEY = xbmcaddon.Addon(id=_PLUGIN_NAME).getSetting('wykop.key')
API_SECRET = xbmcaddon.Addon(id=_PLUGIN_NAME).getSetting('wykop.secret')

# wykop paths
_API_URL = 'https://wykop.pl/api/v3'

# automex
_SHARED_LIMIT = xbmcaddon.Addon(id=_PLUGIN_NAME).getSetting('wykop.shared')


def get_shared_emails() -> list:
    shared_em = []
    for i in range(3):
        she = xbmcaddon.Addon(id=_PLUGIN_NAME).getSetting(f'wykop.sh.e{i + 1}')
        if "@" in she:
            shared_em.append(she)

    return shared_em
